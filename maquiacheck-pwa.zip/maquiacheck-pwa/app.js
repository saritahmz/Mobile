const products = [
  { name: "Fit Me Matte + Poreless", brand: "Maybelline", category: "Base", price: 54.90, store: "Amazon", icon: "◉" },
  { name: "SuperStay Active Wear", brand: "Maybelline", category: "Base", price: 69.90, store: "Droga Raia", icon: "◉" },
  { name: "Fit Me Corretivo", brand: "Maybelline", category: "Corretivo", price: 39.90, store: "Época Cosméticos", icon: "◌" },
  { name: "Ruby Kisses Blush", brand: "Ruby Rose", category: "Blush", price: 18.90, store: "Shopee", icon: "●" },
  { name: "Máscara Lash Sensational", brand: "Maybelline", category: "Máscara de cílios", price: 47.90, store: "Amazon", icon: "✦" },
  { name: "Super Stay Vinyl Ink", brand: "Maybelline", category: "Batom", price: 59.90, store: "Sephora", icon: "●" }
];

const brand = document.querySelector("#brand");
const category = document.querySelector("#category");
const searchBtn = document.querySelector("#searchBtn");
const list = document.querySelector("#productList");
const count = document.querySelector("#resultCount");

function money(value) {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function render(items) {
  count.textContent = `${items.length} ${items.length === 1 ? "item" : "itens"}`;

  if (!items.length) {
    list.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">⌕</div>
        <h3>Nenhum produto encontrado</h3>
        <p>Tente outra marca ou categoria.</p>
      </div>`;
    return;
  }

  const lowest = Math.min(...items.map(p => p.price));

  list.innerHTML = items
    .sort((a, b) => a.price - b.price)
    .map(p => `
      <article class="product-card">
        <div class="product-image" aria-hidden="true">${p.icon}</div>
        <div>
          ${p.price === lowest ? '<span class="best">MELHOR PREÇO</span>' : ""}
          <h3>${p.name}</h3>
          <p class="product-meta">${p.brand} · ${p.category}</p>
          <div class="price-row">
            <div>
              <div class="price">${money(p.price)}</div>
              <div class="store">${p.store}</div>
            </div>
          </div>
        </div>
      </article>
    `).join("");
}

function search() {
  const b = brand.value.trim().toLowerCase();
  const c = category.value.toLowerCase();

  const filtered = products.filter(p =>
    (!b || p.brand.toLowerCase().includes(b)) &&
    (!c || p.category.toLowerCase() === c)
  );

  render(filtered);
}

searchBtn.addEventListener("click", search);
brand.addEventListener("keydown", e => {
  if (e.key === "Enter") search();
});

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("sw.js"));
}
